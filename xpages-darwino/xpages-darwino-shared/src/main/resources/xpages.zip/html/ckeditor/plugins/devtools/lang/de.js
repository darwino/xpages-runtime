﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("devtools","de",{title:"Elementinformationen",dialogName:"Name des Dialogfensters",tabName:"Name der Registerkarte",elementId:"Element-ID",elementType:"Elementtyp"});