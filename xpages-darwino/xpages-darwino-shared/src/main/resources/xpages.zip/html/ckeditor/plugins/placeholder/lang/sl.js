﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","sl",{title:"Lastnosti ograde",toolbar:"Ustvari ogrado",name:"Ime ograde",invalidName:"Ograda ne sme biti prazna in ne sme vsebovati nobenega od naslednjih znakov: [, ], <, >",pathName:"ograda"});