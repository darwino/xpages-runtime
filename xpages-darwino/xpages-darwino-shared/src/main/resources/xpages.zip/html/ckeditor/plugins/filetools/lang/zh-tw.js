﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","zh-tw",{loadError:"讀取檔案期間發生錯誤。",networkError:"上傳檔案期間發生網路錯誤。",httpError404:"上傳檔案期間發生 HTTP 錯誤（404：找不到檔案）。",httpError403:"上傳檔案期間發生 HTTP 錯誤（403：禁止）。",httpError:"上傳檔案期間發生 HTTP 錯誤（錯誤狀態：%1）。",noUrlError:"未定義上傳 URL。",responseError:"伺服器回應不正確。"});