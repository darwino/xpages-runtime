﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","cs",{alt:"Alternativní text",btnUpload:"Odeslat na server",captioned:"Zachycený obrázek",captionPlaceholder:"Popisek",infoTab:"Informace o obrázku",lockRatio:"Uzamknout poměr",menu:"Vlastnosti obrázku",pathName:"obrázek",pathNameCaption:"titulek",resetSize:"Obnovit velikost",resizer:"Změnit velikost klepnutím a přetažením",title:"Vlastnosti obrázku",uploadTab:"Odeslat",urlMissing:"Chybí zdrojová adresa URL obrázku."});