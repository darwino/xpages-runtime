﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","ru",{alt:"Альтернативный текст",btnUpload:"Отправить на сервер",captioned:"Изображение с заголовком",captionPlaceholder:"Название",infoTab:"Информация об изображении",lockRatio:"Сохранять пропорции",menu:"Свойства изображения",pathName:"изображение",pathNameCaption:"заголовок",resetSize:"Сбросить размер",resizer:"Нажмите левую кнопку мыши и потяните, чтобы изменить размер",title:"Свойства изображения",uploadTab:"Передать",urlMissing:"Отсутствует URL источника изображения."});