﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","ja",{title:"プレースホルダーのプロパティー",toolbar:"プレースホルダーの作成",name:"プレースホルダー名",invalidName:"プレースホルダーは空にすることも、次の文字のいずれかを含むこともできません: [, ]、<、>",pathName:"プレースホルダー"});