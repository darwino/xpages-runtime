﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","ar",{alt:"النص البديل",btnUpload:"ارسال الى وحدة الخدمة",captioned:"صورة ذات تسمية توضيحية",captionPlaceholder:"التسمية التوضيحية",infoTab:"معلومات الصورة",lockRatio:"نسبة الاقفال",menu:"خصائص الصورة",pathName:"الصورة",pathNameCaption:"التسمية التوضيحية",resetSize:"ارجاع الحجم",resizer:"اضغط مع السحب للتغيير الحجم",title:"خصائص الصورة",uploadTab:"‏تحميل‏",urlMissing:"عنوان URL الخاص بمصدر الصورة غير موجود."});