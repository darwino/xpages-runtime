﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","sk",{title:"Vlastnosti zástupného objektu",toolbar:"Vytvoriť zástupný objekt",name:"Názov zástupného objektu",invalidName:"Zástupný objekt nemôže byť prázdny ani obsahovať tieto znaky: [, ], <, >",pathName:"zástupný objekt"});