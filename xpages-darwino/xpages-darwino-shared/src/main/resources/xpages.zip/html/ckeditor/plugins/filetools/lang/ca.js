﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","ca",{loadError:"S'ha produït un error durant la lectura del fitxer.",networkError:"S'ha produït un error de xarxa durant la càrrega del fitxer.",httpError404:"S'ha produït un error d'HTTP durant la càrrega del fitxer (404: No s'ha trobat el fitxer).",httpError403:"S'ha produït un error d'HTTP durant la càrrega del fitxer (403: No permès).",httpError:"S'ha produït un error d'HTTP durant la càrrega del fitxer (estat d'error: %1).",noUrlError:"No s'ha definit l'URL de càrrega.",responseError:"Resposta de servidor incorrecta."});