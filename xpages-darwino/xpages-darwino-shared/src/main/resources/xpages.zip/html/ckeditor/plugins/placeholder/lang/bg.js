﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","bg",{title:"Свойства на контейнер",toolbar:"Създаване на контейнер",name:"Име на контейнер'",invalidName:"Контейнерът не може да бъде празен и не може да съдържа някой от следните символи: [, ], <, >",pathName:"контейнер"});