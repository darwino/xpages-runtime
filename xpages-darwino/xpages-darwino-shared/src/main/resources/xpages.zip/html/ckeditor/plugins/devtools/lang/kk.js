﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("devtools","kk",{title:"Элемент ақпараты",dialogName:"Диалог терезесінің аты",tabName:"Қойынды аты",elementId:"Элемент идентификаторы",elementType:"Элемент түрі"});