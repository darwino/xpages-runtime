﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","pt-br",{alt:"Texto Alternativo",btnUpload:"Enviar para o Servidor",captioned:"Imagem com legenda",captionPlaceholder:"Legenda",infoTab:"Informações da Imagem",lockRatio:"Bloquear Proporção",menu:"Propriedades de Imagem",pathName:"imagem",pathNameCaption:"legenda",resetSize:"Reconfigurar Tamanho",resizer:"Clique e arraste para redimensionar",title:"Propriedades de Imagem",uploadTab:"Fazer upload",urlMissing:"A URL de origem da imagem está ausente."});