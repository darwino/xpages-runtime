﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","el",{alt:"Εναλλακτικό κείμενο",btnUpload:"Αποστολή στον εξυπηρετητή",captioned:"Εικόνα με λεζάντα",captionPlaceholder:"Λεζάντα",infoTab:"Πληροφορίες εικόνας",lockRatio:"Κλείδωμα αναλογιών",menu:"Ιδιότητες εικόνας",pathName:"εικόνα",pathNameCaption:"λεζάντα",resetSize:"Επαναφορά μεγέθους",resizer:"Πατήστε και σύρετε για αλλαγή μεγέθους",title:"Ιδιότητες εικόνας",uploadTab:"Μεταφόρτωση στην υπηρεσία",urlMissing:"Δεν έχει οριστεί η διεύθυνση URL για την προέλευση εικόνας."});