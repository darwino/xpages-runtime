﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","mk",{title:"Математика во TeX",button:"Математика",dialogInput:"Напишете го вашиот TeX овде",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"Документација за TeX",loading:"вчитување...",pathName:"математика"});