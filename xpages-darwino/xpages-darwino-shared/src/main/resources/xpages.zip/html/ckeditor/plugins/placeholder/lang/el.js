﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","el",{title:"Ιδιότητες πλαισίου κράτησης θέσης",toolbar:"Δημιουργία πλαισίου κράτησης θέσης",name:"Σύμβολο κράτησης θέσης",invalidName:"Το σύμβολο κράτησης θέσης δεν μπορεί να περιέχει τους ακόλουθους χαρακτήρες: [, ], <, >",pathName:"σύμβολο κράτησης θέσης"});