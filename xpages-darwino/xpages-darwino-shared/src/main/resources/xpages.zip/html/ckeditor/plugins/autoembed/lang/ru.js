﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("autoembed","ru",{embeddingInProgress:"Выполняется попытка встроить вставленный URL...",embeddingFailed:"Невозможно автоматически встроить этот URL."});