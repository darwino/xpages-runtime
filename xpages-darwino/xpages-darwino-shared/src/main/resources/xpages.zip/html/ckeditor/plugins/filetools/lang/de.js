﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","de",{loadError:"Beim Lesen der Datei ist ein Fehler aufgetreten.",networkError:"Beim Hochladen der Datei ist ein Netzfehler aufgetreten.",httpError404:"Beim Hochladen der Datei ist ein HTTP-Fehler aufgetreten (404: Datei nicht gefunden).",httpError403:"Beim Hochladen der Datei ist ein HTTP-Fehler aufgetreten (403: Unzulässig).",httpError:"Beim Hochladen der Datei ist ein HTTP-Fehler aufgetreten (Fehlerstatus: %1).",noUrlError:"Upload-URL ist nicht definiert.",responseError:"Falsche Serverantwort."});