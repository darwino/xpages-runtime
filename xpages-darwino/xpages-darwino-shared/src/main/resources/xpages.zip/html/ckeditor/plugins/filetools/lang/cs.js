﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","cs",{loadError:"Během čtení souboru došlo k chybě.",networkError:"Během odesílání souboru došlo k chybě sítě.",httpError404:"Během odesílání souboru došlo k chybě HTTP (404: soubor nebyl nalezen).",httpError403:"Během odesílání souboru došlo k chybě HTTP (403: zakázáno).",httpError:"Během odesílání souboru došlo k chybě HTTP (chybový stav: %1).",noUrlError:"Adresa URL pro odesílání není definována.",responseError:"Nesprávná odpověď serveru."});