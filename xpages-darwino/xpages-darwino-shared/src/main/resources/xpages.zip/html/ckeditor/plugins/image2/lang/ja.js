﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","ja",{alt:"代替テキスト",btnUpload:"サーバーに送信",captioned:"表題付きイメージ",captionPlaceholder:"表題",infoTab:"イメージ情報",lockRatio:"比率の固定",menu:"イメージ・プロパティー",pathName:"イメージ",pathNameCaption:"表題",resetSize:"サイズのリセット",resizer:"クリック・アンド・ドラッグでサイズ変更",title:"イメージ・プロパティー",uploadTab:"アップロード",urlMissing:"イメージのソース URL がありません。"});