﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","nl",{title:"Eigenschappen plaatshouder",toolbar:"Plaatshouder maken",name:"Naam van plaatshouder",invalidName:"De plaatshouder moet een waarde hebben en mag niet de volgende tekens bevatten: [, ], <, >",pathName:"plaatshouder"});