﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","fr",{title:"Propriétés de marque de réservation",toolbar:"Créer une marque de réservation",name:"Nom de la marque de réservation",invalidName:"La marque de réservation ne peut pas être vide et elle ne peut contenir aucun des caractères suivants : [, ], <, >",pathName:"marque de réservation"});