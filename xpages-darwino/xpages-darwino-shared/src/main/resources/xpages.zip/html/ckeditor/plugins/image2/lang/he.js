﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","he",{alt:"תמליל חלופי ",btnUpload:"משלוח לשרת",captioned:"תמונה עם כיתוב",captionPlaceholder:"כיתוב ",infoTab:"פרטי תמונה ",lockRatio:"נעילת יחס ממדים",menu:"תכונות תמונה",pathName:"תמונה",pathNameCaption:"כיתוב ",resetSize:"איפוס גודל",resizer:"לחצו וגררו כדי לשנות גודל",title:"תכונות תמונה",uploadTab:"טעינה",urlMissing:"ה-URL של מקור התמונה חסר."});