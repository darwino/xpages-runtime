﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","zh",{loadError:"读取文件期间出错。",networkError:"上传文件期间出现网络错误。",httpError404:"上传文件期间出现 HTTP 错误（404：找不到文件）。",httpError403:"上传文件期间出现 HTTP 错误（403：已禁止）",httpError:"上传文件期间出现 HTTP 错误（错误状态：%1）。",noUrlError:"未定义上传 URL。",responseError:"错误的服务器响应。"});