﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("autoembed","ja",{embeddingInProgress:"貼り付けられた URL を埋め込み中...",embeddingFailed:"この URL を自動的に埋め込むことができませんでした。"});