﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","kk",{loadError:"Файлды оқу кезінде қателік туындады.",networkError:"Желі қателігі файлды жүктеу кезінде анықталды.",httpError404:"HTTP қателігі файлды жүктеу кезінде (404: файл табылмады) қателік туындады.",httpError403:"HTTP қателігі файлды жүктеу кезінде (403: тиым салынған) қателік туындады.",httpError:"HTTP қателігі файлды жүктеу кезінде (қателік күйі: %1) қателік туындады.",noUrlError:"URL кері қотаруы анықталмаған.",responseError:"Дұрыс емес сервер сұрауы."});