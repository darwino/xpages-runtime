﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","fr",{alt:"Texte de remplacement",btnUpload:"L'envoyer au serveur",captioned:"image avec légende",captionPlaceholder:"Légende",infoTab:"Infos sur l'image",lockRatio:"Verrouiller le ratio",menu:"Propriétés de l'image",pathName:"image",pathNameCaption:"légende",resetSize:"Réinitialiser la taille",resizer:"Cliquer et faire glisser pour redimensionner",title:"Propriétés de l'image",uploadTab:"Envoyer par téléchargement",urlMissing:"L'URL source de l'image est manquante."});