﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","de",{alt:"Alternativer Text",btnUpload:"An den Server senden",captioned:"Beschriftetes Bild",captionPlaceholder:"Beschriftung",infoTab:"Bildinformationen",lockRatio:"Seitenverhältnis sperren",menu:"Grafikeigenschaften",pathName:"Bild",pathNameCaption:"Beschriftung ",resetSize:"Größe zurücksetzen",resizer:"Zum Ändern der Größe klicken und ziehen",title:"Grafikeigenschaften",uploadTab:"Hochladen",urlMissing:"Die Quell-URL für die Grafik fehlt."});