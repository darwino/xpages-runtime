﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","eu",{loadError:"Errorea fitxategia irakurtzean.",networkError:"Sare-errorea fitxategia kargatzean.",httpError404:"HTTP errorea fitxategia kargatzean (404: fitxategia ez da aurkitu).",httpError403:"HTTP errorea fitxategia kargatzean (403: debekatuta).",httpError:"HTTP errorea fitxategia kargatzean (errore-egoera: %1).",noUrlError:"Kargatzeko URLa ez da zehaztu.",responseError:"Zerbitzariaren erantzuna ez da zuzena."});