﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","tr",{loadError:"Dosya okunurken hata oluştu.",networkError:"Dosya karşıya yüklenirken ağ hatası oluştu.",httpError404:"Dosya karşıya yüklenirken HTTP hatası oluştu (404: Dosya bulunamadı).",httpError403:"Dosya karşıya yüklenirken HTTP hatası oluştu (403: Yasak).",httpError:"Dosya karşıya yüklenirken HTTP hatası oluştu (hata durumu: %1).",noUrlError:"Karşıya yükleme URL'si tanımlanmadı.",responseError:"Hatalı sunucu yanıtı."});