﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","el",{loadError:"Παρουσιάστηκε σφάλμα κατά την ανάγνωση αρχείου.",networkError:"Παρουσιάστηκε σφάλμα δικτύου κατά τη μεταφόρτωση αρχείου.",httpError404:"Παρουσιάστηκε σφάλμα HTTP κατά τη μεταφόρτωση αρχείου (404: File not found).",httpError403:"Παρουσιάστηκε σφάλμα HTTP κατά τη μεταφόρτωση αρχείου (403: Forbidden).",httpError:"Παρουσιάστηκε σφάλμα HTTP κατά τη μεταφόρτωση αρχείου (Κατάσταση σφάλματος: %1).",noUrlError:"Η διεύθυνση URL μεταφόρτωσης δεν έχει οριστεί.",responseError:"Εσφαλμένη απόκριση εξυπηρετητή."});