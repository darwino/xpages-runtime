﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("autoembed","sl",{embeddingInProgress:"Sistem poskuša vdelati prilepljeni URL ...",embeddingFailed:"Tega URL-ja ni mogoče samodejno vdelati."});