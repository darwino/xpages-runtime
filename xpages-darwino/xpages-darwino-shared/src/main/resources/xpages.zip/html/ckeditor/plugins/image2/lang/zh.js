﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","zh",{alt:"备用文本",btnUpload:"将其发送到服务器",captioned:"带有文字说明的图像",captionPlaceholder:"文字说明",infoTab:"图像信息",lockRatio:"锁定比例",menu:"图像属性",pathName:"image",pathNameCaption:"文字说明",resetSize:"重置大小",resizer:"单击并拖动以调整大小",title:"图像属性",uploadTab:"上载",urlMissing:"缺少图像源 URL。"});