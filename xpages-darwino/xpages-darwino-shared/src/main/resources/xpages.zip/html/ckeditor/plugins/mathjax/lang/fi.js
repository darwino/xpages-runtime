﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","fi",{title:"Matematiikkaympäristö TeX-järjestelmässä",button:"Matematiikka",dialogInput:"Kirjoita TeX-koodi tähän",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"TeX-käyttöohjeet",loading:"lataus on meneillään...",pathName:"matematiikka"});