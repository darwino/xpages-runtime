﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","ja",{loadError:"ファイルを読み込み中にエラーが発生しました。",networkError:"ファイルのアップロード中にネットワーク・エラーが発生しました。",httpError404:"ファイルをアップロード中に HTTP エラーが発生しました (404: ファイルが見つかりません)。",httpError403:"ファイルをアップロード中に HTTP エラーが発生しました (403: 禁止)。",httpError:"ファイルをアップロード中に HTTP エラーが発生しました (エラー状況: %1).",noUrlError:"アップロード URL が定義されていません。",responseError:"サーバーの応答が正しくありません。"});