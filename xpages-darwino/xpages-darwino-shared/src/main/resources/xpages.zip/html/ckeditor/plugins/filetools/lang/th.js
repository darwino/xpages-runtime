﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","th",{loadError:"มีข้อผิดพลาดเกิดขึ้นระหว่างการอ่านไฟล์",networkError:"มีข้อผิดพลาดเครือข่ายเกิดขึ้นระหว่างการอัพโหลดไฟล์",httpError404:"มีข้อผิดพลาด HTTP เกิดขึ้นระหว่างการอัพโหลดไฟล์ (404: ไม่พบไฟล์)",httpError403:"มีข้อผิดพลาด HTTP เกิดขึ้นระหว่างการอัพโหลดไฟล์ (403: ไม่ได้รับอนุญาต)",httpError:"มีข้อผิดพลาด HTTP เกิดขึ้นระหว่างการอัพโหลดไฟล์ (สถานะข้อผิดพลาด: %1)",noUrlError:"ไม่ได้กำหนด URL การอัพโหลด",responseError:"การตอบกลับของเซิร์ฟเวอร์ไม่ถูกต้อง"});