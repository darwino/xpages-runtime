﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("autoembed","nb",{embeddingInProgress:"Prøver å bygge inn innlimt URL...",embeddingFailed:"Denne URLen kunne ikke bygges inn automatisk."});