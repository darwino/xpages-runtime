﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","bs",{title:"Osobine znaka rezervisanog mjesta",toolbar:"Kreiraj znak rezervisanog mjesta",name:"Ime znaka rezervisanog mjesta",invalidName:"Znak rezervisanog mjesta ne smije biti prazan i ne smije sadržavati sljedeće znakove: [, ], <, >",pathName:"znak rezervisanog mjesta"});