﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","ko",{loadError:"파일 읽기 중 오류가 발생했습니다.",networkError:"파일 업로드 중 네트워크 오류가 발생했습니다.",httpError404:"파일 업로드 중 HTTP 오류가 발생했습니다(404: 파일을 찾을 수 없음).",httpError403:"파일 업로드 중 HTTP 오류가 발생했습니다(403: 금지).",httpError:"파일 업로드 중 HTTP 오류가 발생했습니다(오류 상태: %1).",noUrlError:"업로드 URL이 정의되어 있지 않습니다.",responseError:"올바르지 않은 서버 응답입니다."});