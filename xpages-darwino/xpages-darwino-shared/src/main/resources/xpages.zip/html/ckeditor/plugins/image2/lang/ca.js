﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","ca",{alt:"Text alternatiu",btnUpload:"Envia'l a un servidor",captioned:"Imatge amb llegenda",captionPlaceholder:"Llegenda",infoTab:"Informació de la imatge",lockRatio:"Bloca la relació",menu:"Propietats de la imatge",pathName:"imatge",pathNameCaption:"llegenda",resetSize:"Restableix la mida",resizer:"Feu clic i arrossegueu per canviar la mida",title:"Propietats de la imatge",uploadTab:"Carrega",urlMissing:"Falta l'URL d'origen de la imatge."});