﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","ja",{title:"TeX 形式での数学表現",button:"数学",dialogInput:"ここに TeX を記述してください",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"TeX 文書",loading:"ロード中...",pathName:"math"});