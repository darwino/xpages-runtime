﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","ar",{loadError:"حدث خطأ أثناء قراءة الملف.",networkError:"حدث خطأ بشبكة الاتصال أثناء تحميل الملف.",httpError404:"حدث خطأ HTTP أثناء تحميل الملف (404: الملف غير موجود).",httpError403:"حدث خطأ HTTP أثناء تحميل الملف (403: غير مسموح به).",httpError:"حدث خطأ HTTP أثناء تحميل الملف (حالة الخطأ: %1).",noUrlError:"عنوان URL للتحميل غير محدد.",responseError:"استجابة غير صحيحة لوحدة الخدمة."});