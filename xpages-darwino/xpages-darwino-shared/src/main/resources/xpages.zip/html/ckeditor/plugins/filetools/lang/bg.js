﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","bg",{loadError:"Възникна грешка по време на четене на файл.",networkError:"Възникна мрежова грешка по време на качване на файл.",httpError404:"Възникна HTTP грешка по време на качване на файл (404: Файлът не е намерен).",httpError403:"Възникна HTTP грешка по време на качване на файл (403: Забранен).",httpError:"Възникна HTTP грешка по време на качване на файл (състояние на грешка: %1).",noUrlError:"Качването на URL адрес не е определено.",responseError:"Неправилен отговор от сървър."});