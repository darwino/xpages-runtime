﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","hu",{loadError:"Hiba történt a fájl olvasása során.",networkError:"Hálózati hiba történt a fájl feltöltése során.",httpError404:"HTTP hiba történt a fájl feltöltése során (404: A fájl nem található).",httpError403:"HTTP hiba történt a fájl feltöltése során (403: Tiltott).",httpError:"HTTP hiba történt a fájl feltöltése során (hibaállapot: %1).",noUrlError:"Nincs megadva a feltöltési URL-cím.",responseError:"Helytelen kiszolgálói válasz."});