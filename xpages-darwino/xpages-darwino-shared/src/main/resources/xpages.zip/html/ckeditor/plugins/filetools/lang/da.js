﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","da",{loadError:"Der er opstået en fejl under fillæsning.",networkError:"Der er opstået en netværksfejl under filuploadning.",httpError404:"Der er opstået en HTTP-fejl under filuploadning (404: Fil findes ikke).",httpError403:"Der er opstået en HTTP-fejl under filuploadning (403: Ikke tilladt).",httpError:"Der er opstået en HTTP-fejl under filuploadning (fejlstatus: %1).",noUrlError:"Upload-URL er ikke defineret.",responseError:"Forkert serversvar."});