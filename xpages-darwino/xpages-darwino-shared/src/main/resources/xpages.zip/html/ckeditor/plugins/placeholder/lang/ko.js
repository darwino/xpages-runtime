﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","ko",{title:"플레이스홀더 특성",toolbar:"플레이스홀더 작성",name:"플레이스홀더 이름'",invalidName:"플레이스홀더가 비어있을 수 없으며 다음 문자를 포함할 수 없음: [, ], <, >",pathName:"플레이스홀더"});