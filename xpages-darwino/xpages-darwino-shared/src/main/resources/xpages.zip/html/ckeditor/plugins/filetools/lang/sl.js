﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","sl",{loadError:"Med branjem datoteke je prišlo do napake.",networkError:"Med nalaganjem datoteke je prišlo do omrežne napake.",httpError404:"Med nalaganjem datoteke je prišlo do napake HTTP (404: datoteke ni mogoče najti).",httpError403:"Med nalaganjem datoteke je prišlo do napake HTTP (403: prepovedano).",httpError:"Med nalaganjem datoteke je prišlo do napake HTTP (status napake: %1).",noUrlError:"URL za nalaganje ni definiran.",responseError:"Nepravilen odziv strežnika."});