﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","ca",{title:"Propietats de marcador",toolbar:"Crea marcador",name:"Nom del marcador'",invalidName:"El marcador no pot ser buit i no pot contenir cap dels caràcters següents: [, ], <, >",pathName:"marcador"});