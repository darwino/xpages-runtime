﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","da",{title:"Egenskaber for pladsholder",toolbar:"Opret pladsholder",name:"Navn på pladsholder",invalidName:"Navnet på pladsholderen skal udfyldes og må ikke indeholde nogen af de følgende tegn: [, ], <, >",pathName:"pladsholder"});