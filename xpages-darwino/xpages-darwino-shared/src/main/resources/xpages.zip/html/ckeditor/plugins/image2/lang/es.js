﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","es",{alt:"Texto alternativo",btnUpload:"Enviar al servidor",captioned:"Imagen con título",captionPlaceholder:"Título",infoTab:"Información de imagen",lockRatio:"Bloquear proporción",menu:"Propiedades de la imagen",pathName:"image",pathNameCaption:"título",resetSize:"Restablecer tamaño",resizer:"Pulsar y arrastrar para cambiar el tamaño",title:"Propiedades de la imagen",uploadTab:"Subir",urlMissing:"Falta el URL de origen de imagen."});