﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","el",{title:"Μαθηματικά στο TeX",button:"Μαθηματικά",dialogInput:"Πληκτρολογήστε το κείμενο TeX εδώ",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"Τεκμηρίωση του TeX",loading:"φόρτωση...",pathName:"μαθηματικά"});