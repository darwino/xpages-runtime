﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","pt-br",{loadError:"Ocorreu um erro durante a leitura do arquivo.",networkError:"Ocorreu um erro de rede durante o upload de arquivo.",httpError404:"Ocorreu um erro de HTTP durante o upload de arquivo (404: Arquivo não localizado).",httpError403:"Ocorreu um erro de HTTP durante o upload de arquivo (403: Proibido).",httpError:"Ocorreu um erro de HTTP durante o upload de arquivo (status do erro: %1).",noUrlError:"A URL de upload não está definida.",responseError:"Resposta incorreta do servidor."});