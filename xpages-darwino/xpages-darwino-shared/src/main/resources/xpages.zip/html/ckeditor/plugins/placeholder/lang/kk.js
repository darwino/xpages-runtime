﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","kk",{title:"Толтырғыш сипаттары",toolbar:"Толтырғыш жасау",name:"Орын толтырғыш атауы",invalidName:"Орын толтырғыш бос болмауы керек және оның құрамында мына таңбалар болмауы керек: [, ], <, >",pathName:"толтырғыш"});