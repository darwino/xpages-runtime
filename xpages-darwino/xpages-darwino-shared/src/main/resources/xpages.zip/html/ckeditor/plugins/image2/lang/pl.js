﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","pl",{alt:"Tekst zastępczy",btnUpload:"Wyślij do serwera",captioned:"Podpisany obrazek",captionPlaceholder:"Podpis",infoTab:"Informacje o obrazie",lockRatio:"Zachowaj proporcje",menu:"Właściwości obrazu",pathName:"obraz",pathNameCaption:"podpis",resetSize:"Resetuj wielkość",resizer:"Kliknij i przeciągnij, aby zmienić wielkość",title:"Właściwości obrazu",uploadTab:"Prześlij",urlMissing:"Brak adresu URL źródła obrazu."});