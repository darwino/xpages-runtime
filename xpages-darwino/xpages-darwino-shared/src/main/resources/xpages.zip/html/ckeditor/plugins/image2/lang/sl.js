﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","sl",{alt:"Nadomestno besedilo",btnUpload:"Pošlji strežniku",captioned:"Slika v napisu",captionPlaceholder:"Napis",infoTab:"Informacije o sliki",lockRatio:"Zakleni razmerje",menu:"Lastnosti slike",pathName:"slika",pathNameCaption:"napis",resetSize:"Ponastavi velikost",resizer:"Kliknite in povlecite, da spremenite velikost",title:"Lastnosti slike",uploadTab:"Naloži",urlMissing:"URL izvora slike manjka."});