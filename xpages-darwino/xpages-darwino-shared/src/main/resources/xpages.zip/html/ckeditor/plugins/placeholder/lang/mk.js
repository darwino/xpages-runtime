﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","mk",{title:"Својства на резервирано место",toolbar:"Создај резервирано место",name:"Име на резервирано место'",invalidName:"Резервираното место не може да биде празно и не може да ги содржи следниве знаци: [, ], <, >",pathName:"резервирано место"});