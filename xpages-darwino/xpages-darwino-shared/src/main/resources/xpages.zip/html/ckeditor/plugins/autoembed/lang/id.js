﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("autoembed","id",{embeddingInProgress:"Mencoba untuk menyematkan URL yang ditempelkan...",embeddingFailed:"URL ini tidak dapat disematkan secara otomatis."});