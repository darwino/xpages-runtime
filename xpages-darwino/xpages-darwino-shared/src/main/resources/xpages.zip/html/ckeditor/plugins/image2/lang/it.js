﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","it",{alt:"Testo alternativo",btnUpload:"Invia al server",captioned:"Immagine con sottotitolo",captionPlaceholder:"Didascalia",infoTab:"Info su immagine",lockRatio:"Blocca percentuale",menu:"Proprietà immagine",pathName:"immagine",pathNameCaption:"sottotitolo",resetSize:"Reimposta dimensione",resizer:"Fare clic e trascinare per ridimensionare",title:"Proprietà immagine",uploadTab:"Carica",urlMissing:"L'URL di origine dell'immagine è assente."});