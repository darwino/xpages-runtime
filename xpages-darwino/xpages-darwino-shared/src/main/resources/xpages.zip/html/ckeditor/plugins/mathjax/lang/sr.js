﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","sr",{title:"Matematika u TeX-u",button:"Matematika",dialogInput:"Ovde unesite TeX kôd",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"Dokumentacija za TeX",loading:"Učitava se…",pathName:"matematika"});