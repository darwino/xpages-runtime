﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","ca",{title:"Matemàtiques a TeX",button:"Matemàtiques",dialogInput:"Escriviu el vostre TeX aquí",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"Documentació de TeX",loading:"S'està carregant...",pathName:"matemàtiques"});