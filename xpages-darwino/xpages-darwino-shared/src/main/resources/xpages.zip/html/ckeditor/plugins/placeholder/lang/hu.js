﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","hu",{title:"Helykitöltő tulajdonságai",toolbar:"Helykitöltő létrehozása",name:"Helykitöltő neve",invalidName:"A helykitöltő nem lehet üres, és nem tartalmazhatja a következő karaktereket: [, ], <, >",pathName:"helykitöltő"});