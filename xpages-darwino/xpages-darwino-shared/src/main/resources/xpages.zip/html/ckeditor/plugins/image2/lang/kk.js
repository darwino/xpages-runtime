﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","kk",{alt:"Балама мәтін",btnUpload:"Оны серверге жіберу",captioned:"Аты бар кескін",captionPlaceholder:"Тақырып",infoTab:"Кескін ақпараты",lockRatio:"Коэффициентті құлыптау",menu:"Сурет сипаттары",pathName:"кескін",pathNameCaption:"тақырып",resetSize:"Өлшемді қайта орнату",resizer:"Өлшемді өзгерту үшін басып сүйреу",title:"Сурет сипаттары",uploadTab:"Жүктеп салу",urlMissing:"Сурет көзінің URL мекенжайы жоқ."});