﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","sk",{loadError:"Nastala chyba počas čítania súboru.",networkError:"Nastala chyba siete počas odosielania súboru.",httpError404:"Nastala chyba HTTP počas odosielania súboru (404: Súbor sa nenašiel).",httpError403:"Nastala chyba HTTP počas odosielania súboru (403: Zakázané).",httpError:"Nastala chyba HTTP počas odosielania súboru (stav chyby: %1).",noUrlError:"Nie je definovaná adresa URL pre odosielanie.",responseError:"Nesprávna odpoveď servera."});