﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","de",{title:"Mathematik in TeX",button:"Mathematik",dialogInput:"TeX hier schreiben",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"TeX-Dokumentation",loading:"wird geladen...",pathName:"Mathematik"});