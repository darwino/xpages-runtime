﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","ro",{alt:"Text alternativ",btnUpload:"Trimiteţi-l la server",captioned:"Imagine cu subtitlu",captionPlaceholder:"Subtitlu",infoTab:"Informaţii imagine",lockRatio:"Raport de blocare",menu:"Proprietăţi imagine",pathName:"imagine",pathNameCaption:"titlu",resetSize:"Dimensiune resetare",resizer:"Faceţi clic şi glisaţi pentru a redimensiona",title:"Proprietăţi imagine",uploadTab:"Încărcare",urlMissing:"URL sursă imagine lipseşte."});