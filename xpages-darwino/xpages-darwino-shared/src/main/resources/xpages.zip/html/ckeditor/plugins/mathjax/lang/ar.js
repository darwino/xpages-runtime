﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","ar",{title:"الرياضيات في TeX",button:"الرياضيات",dialogInput:"قم بكتابة TeX الخاص بك هنا",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"وثائق TeX",loading:"جاري التحميل...",pathName:"الرياضيات"});