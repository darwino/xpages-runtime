﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","bg",{title:"Математика в TeX",button:"Математика",dialogInput:"Напишете своя TeX тук",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"Документация на TeX",loading:"Зареждане...",pathName:"Математика"});