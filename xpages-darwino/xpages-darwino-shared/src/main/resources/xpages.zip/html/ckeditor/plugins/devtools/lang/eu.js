﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("devtools","eu",{title:"Elementuaren informazioa",dialogName:"Elkarrizketa leihoaren izena",tabName:"Fitxaren izena",elementId:"Elementuaren IDa",elementType:"Elementu mota"});