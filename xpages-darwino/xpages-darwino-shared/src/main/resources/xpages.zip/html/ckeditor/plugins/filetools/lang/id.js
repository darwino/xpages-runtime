﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","id",{loadError:"Terjadi kesalahan selama pembacaan file.",networkError:"Terjadi kesalahan jaringan selama pengunggahan file.",httpError404:"Terjadi kesalahan HTTP selama pengunggahan file (404: File tidak ditemukan).",httpError403:"Terjadi kesalahan HTTP selama pengunggahan file (403: Dilarang).",httpError:"Terjadi kesalahan HTTP selama pengunggahan file (status kesalahan: %1).",noUrlError:"Pengunggahan URL tidak ditetapkan.",responseError:"Respons server salah."});