﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","sl",{title:"Matematika v TeX",button:"Matematika",dialogInput:"Svoj TeX vnesite tukaj",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"Dokumentacija za TeX",loading:"nalaganje ...",pathName:"matematika"});