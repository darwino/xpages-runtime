﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("devtools","sr",{title:"Informacije o elementu",dialogName:"Naziv prozora sa dijalogom",tabName:"Naziv kartice",elementId:"ID elementa",elementType:"Tip elementa"});