﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","fr",{title:"Mathématiques dans TeX",button:"Math",dialogInput:"Ecrivez votre TeX ici",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"Documentation TeX",loading:"chargement en cours...",pathName:"math"});