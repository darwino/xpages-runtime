﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","fi",{loadError:"On ilmennyt virhe luettaessa tiedostoa.",networkError:"On ilmennyt verkkovirhe siirrettäessä tiedostoa palvelimeen.",httpError404:"On ilmennyt HTTP-virhe siirrettäessä tiedostoa palvelimeen (404: Tiedostoa ei löydy).",httpError403:"On ilmennyt HTTP-virhe siirrettäessä tiedostoa palvelimeen (403: Kielletty).",httpError:"On ilmennyt HTTP-virhe siirrettäessä tiedostoa palvelimeen (virheen tila: %1).",noUrlError:"Siirron URL-osoitetta ei ole määritetty.",responseError:"Palvelimen vastaus on virheellinen."});