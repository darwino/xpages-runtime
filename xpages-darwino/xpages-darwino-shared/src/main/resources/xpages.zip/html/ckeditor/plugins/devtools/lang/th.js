﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("devtools","th",{title:"ข้อมูลอิลิเมนต์",dialogName:"ชื่อหน้าต่างไดอะล็อก",tabName:"ชื่อแท็บ",elementId:"ID ของอิลิเมนต์",elementType:"ชนิดของอิลิเมนต์"});