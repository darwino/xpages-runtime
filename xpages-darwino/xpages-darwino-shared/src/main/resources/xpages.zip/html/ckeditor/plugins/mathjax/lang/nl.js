﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","nl",{title:"Wiskundige formules met TeX",button:"Math",dialogInput:"Schrijf hier uw TeX-invoer",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"TeX-documentatie",loading:"bezig met laden...",pathName:"math"});