﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","pt",{title:"Matemática em TeX",button:"Math",dialogInput:"Escreva o TeX aqui",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"Documentação TeX",loading:"A carregar...",pathName:"math"});