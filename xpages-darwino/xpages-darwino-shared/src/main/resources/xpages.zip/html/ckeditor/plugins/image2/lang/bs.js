﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","bs",{alt:"Alternativni tekst",btnUpload:"Pošalji na server",captioned:"Uhvaćena slika",captionPlaceholder:"Naslov",infoTab:"Podaci slike",lockRatio:"Zaključaj omjer",menu:"Osobine slike",pathName:"slika",pathNameCaption:"naslov",resetSize:"Resetiraj veličinu",resizer:"Kliknite i povucite za promjenu veličine",title:"Osobine slike",uploadTab:"Učitaj",urlMissing:"Nedostaje URL izvora slike."});