﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","ro",{title:"Mathematica în TeX",button:"Math",dialogInput:"Scrieţi-vă textul TeX aici",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"documentaţie TeX",loading:"încărcare...",pathName:"math"});