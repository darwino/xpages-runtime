﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","hu",{title:"Matematika TeX-ben",button:"Matematika",dialogInput:"Írja be ide a TeX szöveget",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"TeX dokumentáció",loading:"betöltés...",pathName:"matematika"});