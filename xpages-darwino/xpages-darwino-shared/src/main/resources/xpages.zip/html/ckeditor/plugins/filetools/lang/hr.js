﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","hr",{loadError:"Dogodila se greška tijekom čitanja datoteke.",networkError:"Dogodila se greška mreže tijekom predavanja datoteke.",httpError404:"Dogodila se HTTP greška tijekom predavanja datoteke (404: Datoteka nije nađena).",httpError403:"Dogodila se HTTP greška tijekom predavanja datoteke (403: Zabranjeno).",httpError:"Dogodila se HTTP greška tijekom predavanja datoteke (status greške: %1).",noUrlError:"URL predavanja nije definiran.",responseError:"Pogrešan odgovor poslužitelja."});