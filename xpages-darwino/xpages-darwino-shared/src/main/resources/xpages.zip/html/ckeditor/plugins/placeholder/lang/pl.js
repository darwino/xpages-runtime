﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","pl",{title:"Właściwości symbolu zastępczego",toolbar:"Utwórz symbol zastępczy",name:"Nazwa symbolu zastępczego",invalidName:"Symbol zastępczy nie może być pusty i nie może zawierać żadnego z następujących znaków: [, ], <, >",pathName:"placeholder"});