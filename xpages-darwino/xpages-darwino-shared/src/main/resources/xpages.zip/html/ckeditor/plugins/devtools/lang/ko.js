﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("devtools","ko",{title:"요소 정보",dialogName:"대화 상자 창 이름",tabName:"탭 이름",elementId:"요소 ID",elementType:"요소 유형"});