﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","bg",{alt:"Алтернативен текст",btnUpload:"Изпращане на сървър",captioned:"Прихванато изображение",captionPlaceholder:"Надпис",infoTab:"Информация за изображение",lockRatio:"Коефициент на заключване",menu:"Свойства на изображение",pathName:"изображение",pathNameCaption:"надпис",resetSize:"Възстановяване на размер",resizer:"Щракнете и плъзнете за преоразмеряване",title:"Свойства на изображение",uploadTab:"Качване",urlMissing:"Липсва URL адреса на източника на изображение."});