﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","da",{alt:"Alternativ tekst",btnUpload:"Send det til serveren",captioned:"Tekstet billede",captionPlaceholder:"Billedtekst",infoTab:"Billedoplysninger",lockRatio:"Lås højde-breddeforhold",menu:"Billedegenskaber",pathName:"billede",pathNameCaption:"billedtekst",resetSize:"Nulstil størrelse",resizer:"Klik og træk for at ændre størrelse",title:"Billedegenskaber",uploadTab:"Upload",urlMissing:"URL til billede mangler."});