﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","ro",{loadError:"A apărut eroare în timpul citirii fişierului.",networkError:"A apărut eroare de reţea în timpul încărcării fişierului.",httpError404:"A apărut eroare HTTP în timpul încărcării fişierului (404: Fişierul nu a fost găsit).",httpError403:"A apărut eroare HTTP în timpul încărcării fişierului (403: este interzis).",httpError:"A apărut eroare HTTP în timpul încărcării fişierului (stare eroare: %1).",noUrlError:"URL de încărcare nu este definit.",responseError:"Răspunsul serverului este incorect."});