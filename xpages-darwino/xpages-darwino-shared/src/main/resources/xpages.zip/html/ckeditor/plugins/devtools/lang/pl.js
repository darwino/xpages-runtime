﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("devtools","pl",{title:"Informacje o elemencie",dialogName:"Nazwa okna dialogowego",tabName:"Nazwa karty",elementId:"Identyfikator elementu",elementType:"Typ elementu"});