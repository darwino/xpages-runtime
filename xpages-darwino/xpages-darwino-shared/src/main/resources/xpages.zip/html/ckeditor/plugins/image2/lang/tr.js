﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","tr",{alt:"Diğer Metin",btnUpload:"Sunucuya gönder",captioned:"Alt yazılı resim",captionPlaceholder:"Başlık",infoTab:"Resim Bilgileri",lockRatio:"Kilitleme Oranı",menu:"Resim Özellikleri",pathName:"resim",pathNameCaption:"başlık",resetSize:"Büyüklüğü İlk Durumuna Getir",resizer:"Yeniden boyutlandırmak için tıklatın ve sürükleyin",title:"Resim Özellikleri",uploadTab:"Karşıya Yükle",urlMissing:"Resim kaynağı URL adresi eksik."});