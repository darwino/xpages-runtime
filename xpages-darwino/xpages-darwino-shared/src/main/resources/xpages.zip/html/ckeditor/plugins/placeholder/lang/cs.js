﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","cs",{title:"Vlastnosti zástupného symbolu",toolbar:"Vytvořit zástupný symbol",name:"Název zástupného symbolu'",invalidName:"Zástupný symbol nemůže být prázdný a nesmí obsahovat žádný z následujících znaků: [, ], <, >",pathName:"zástupný symbol"});