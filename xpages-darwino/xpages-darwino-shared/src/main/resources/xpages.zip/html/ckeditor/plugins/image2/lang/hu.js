﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","hu",{alt:"Másodlagos szöveg",btnUpload:"Küldés a kiszolgálóra",captioned:"Feliratos kép",captionPlaceholder:"Felirat",infoTab:"Kép információi",lockRatio:"Zárolási arány",menu:"Képtulajdonságok",pathName:"kép",pathNameCaption:"felirat",resetSize:"Méret alaphelyzetbe állítása",resizer:"Kattintson rá és húzza az átméretezéshez",title:"Képtulajdonságok",uploadTab:"Feltöltés",urlMissing:"A kép forrás URL címe hiányzik."});