﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("devtools","pt",{title:"Informações do elemento",dialogName:"Nome da janela da caixa de diálogo",tabName:"Nome do separador",elementId:"ID do elemento",elementType:"Tipo de elemento"});