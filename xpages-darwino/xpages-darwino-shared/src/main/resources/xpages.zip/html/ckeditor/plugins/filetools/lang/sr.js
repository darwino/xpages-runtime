﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","sr",{loadError:"Došlo je do greške prilikom čitanja datoteke.",networkError:"Došlo je do mrežne greške prilikom otpremanja datoteke.",httpError404:"Došlo je do HTTP greške prilikom otpremanja datoteke (404: Datoteka nije pronađena).",httpError403:"Došlo je do HTTP greške prilikom otpremanja datoteke (403: Zabranjeno).",httpError:"Došlo je do HTTP greške prilikom otpremanja datoteke (status greške: %1).",noUrlError:"URL za otpremanje nije definisan.",responseError:"Neispravan odgovor od servera."});