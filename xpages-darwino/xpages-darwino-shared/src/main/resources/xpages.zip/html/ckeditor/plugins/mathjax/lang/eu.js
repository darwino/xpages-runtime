﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","eu",{title:"Matematikak TeX-en",button:"Matematika",dialogInput:"Idatzi zure TeX-a hemen",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"TeX-en dokumentazioa",loading:"kargatzen...",pathName:"matematika"});