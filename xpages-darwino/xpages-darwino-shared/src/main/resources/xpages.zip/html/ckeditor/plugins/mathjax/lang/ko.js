﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","ko",{title:"TeX의 복소수학",button:"수학",dialogInput:"여기에 TeX 기록",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"TeX 문서",loading:"로드 중...",pathName:"수학"});