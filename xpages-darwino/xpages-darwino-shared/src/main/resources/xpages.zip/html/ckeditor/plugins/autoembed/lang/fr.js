﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("autoembed","fr",{embeddingInProgress:"Tentative d’imbrication d'une URL collée...",embeddingFailed:"Cette URL n'a pas pu être automatiquement imbriquée."});