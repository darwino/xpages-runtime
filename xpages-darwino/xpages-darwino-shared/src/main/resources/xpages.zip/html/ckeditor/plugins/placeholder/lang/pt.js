﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","pt",{title:"Propriedades do marcador de posição",toolbar:"Criar marcador de posição",name:"Nome do marcador de posição",invalidName:"O marcador de posição não pode estar vazio e não pode conter qualquer um dos caracteres que se seguem: [, ], <, >",pathName:"marcador de posição"});