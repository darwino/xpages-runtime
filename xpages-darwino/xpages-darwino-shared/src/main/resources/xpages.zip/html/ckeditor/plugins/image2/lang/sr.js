﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","sr",{alt:"Alternativni tekst",btnUpload:"Pošalji na server",captioned:"Slika sa natpisom",captionPlaceholder:"Natpis",infoTab:"Informacije o slici",lockRatio:"Zaključaj odnos",menu:"Svojstva slike",pathName:"slika",pathNameCaption:"natpis",resetSize:"Ponovo postavi veličinu",resizer:"Kliknite i povucite da biste promenili veličinu",title:"Svojstva slike",uploadTab:"Otpremi",urlMissing:"Nedostaje URL izvora slike."});