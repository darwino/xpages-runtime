﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","he",{loadError:"אירעה שגיאה בקריאת הקובץ. ",networkError:"אירעה שגיאת רשת בטעינת הקובץ.",httpError404:"אירעה שגיאת HTTP בטעינת הקובץ (404:‏ הקובץ לא נמצא).",httpError403:"אירעה שגיאת HTTP בטעינת הקובץ (403:‏ אסור).",httpError:"אירעה שגיאת HTTP בטעינת הקובץ (מצב שגיאה %1).",noUrlError:"ה-URL לטעינה אינו מוגדר. ",responseError:"תגובת שרת שגויה. "});