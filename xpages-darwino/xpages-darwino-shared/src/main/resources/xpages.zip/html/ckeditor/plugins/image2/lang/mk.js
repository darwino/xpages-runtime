﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","mk",{alt:"Алтернативен текст",btnUpload:"Испрати го до серверот",captioned:"Слика со наслов",captionPlaceholder:"Наслов",infoTab:"Информации за слика",lockRatio:"Заклучи сооднос",menu:"Својства на слика",pathName:"слика",pathNameCaption:"наслов",resetSize:"Постави повторно големина",resizer:"Кликнете и влечете за да ја измените големината",title:"Својства на слика",uploadTab:"Постави",urlMissing:"Недостасува URL-адреса за извор на сликата."});