﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","pl",{loadError:"Wystąpił błąd podczas odczytu pliku.",networkError:"Wystąpił błąd sieciowy podczas przesyłania pliku.",httpError404:"Wystąpił błąd protokołu HTTP podczas przesyłania pliku (404: Nie można znaleźć pliku).",httpError403:"Wystąpił błąd protokołu HTTP podczas przesyłania pliku (403: Zabroniony).",httpError:"Wystąpił błąd protokołu HTTP podczas przesyłania pliku (status błędu: %1).",noUrlError:"Nie zdefiniowano adresu URL przesyłania.",responseError:"Niepoprawna odpowiedź serwera."});