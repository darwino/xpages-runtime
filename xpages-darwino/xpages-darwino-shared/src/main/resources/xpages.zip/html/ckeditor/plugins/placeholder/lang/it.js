﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","it",{title:"Proprietà del segnaposto",toolbar:"Crea segnaposto",name:"Nome segnaposto",invalidName:"Il segnaposto non può essere vuoto e non può contenere i seguenti caratteri: [, ], <, >",pathName:"segnaposto"});