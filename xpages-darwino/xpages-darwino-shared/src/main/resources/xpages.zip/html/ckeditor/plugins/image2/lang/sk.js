﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","sk",{alt:"Alternatívny Text",btnUpload:"Odoslať na server",captioned:"Obrázok s nadpisom",captionPlaceholder:"Nadpis",infoTab:"Informácie o obrázku",lockRatio:"Zamknúť pomer strán",menu:"Vlastnosti obrázka",pathName:"obrázok",pathNameCaption:"nadpis",resetSize:"Obnoviť veľkosť",resizer:"Zmeniť veľkosť kliknutím a potiahnutím",title:"Vlastnosti obrázka",uploadTab:"Odoslať",urlMissing:"Chýba zdrojová adresa URL obrázka."});