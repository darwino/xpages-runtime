﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("devtools","cs",{title:"Informace o prvku",dialogName:"Název dialogového okna",tabName:"Název karty",elementId:"ID prvku",elementType:"Typ prvku"});