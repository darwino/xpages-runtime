﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","eu",{title:"Leku-markaren propietateak",toolbar:"Sortu leku-marka",name:"Leku-markaren izena",invalidName:"Leku-marka ezin da hutsik egon eta ezin ditu honako karaktere hauek eduki: [, ], <, >",pathName:"leku-marka"});