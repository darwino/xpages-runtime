﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","zh-tw",{alt:"替代文字",btnUpload:"將其傳送至伺服器",captioned:"加上標題的影像",captionPlaceholder:"標題",infoTab:"影像資訊",lockRatio:"鎖定比例",menu:"影像內容",pathName:"影像",pathNameCaption:"標題",resetSize:"重設大小",resizer:"按一下並拖曳以調整大小",title:"影像內容",uploadTab:"上傳",urlMissing:"遺漏影像來源 URL。"});