﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","pl",{title:"Formuły matematyczne w języku TeX",button:"Formuła matematyczna",dialogInput:"Wpisz kod TeX w tym miejscu",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"Dokumentacja TeX",loading:"Ładowanie...",pathName:"math"});