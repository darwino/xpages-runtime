﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","zh-tw",{title:"位置保留元內容",toolbar:"建立位置保留元",name:"位置保留元名稱",invalidName:"位置保留元不能空白，也不能包含下列任何字元：[、]、<、>",pathName:"位置保留元"});