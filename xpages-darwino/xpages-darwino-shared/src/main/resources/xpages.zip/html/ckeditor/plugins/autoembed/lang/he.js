﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("autoembed","he",{embeddingInProgress:"נסיון להטביע את ה-URL המודבק...‏",embeddingFailed:"לא ניתן להטביע URL זה אוטומטית. "});