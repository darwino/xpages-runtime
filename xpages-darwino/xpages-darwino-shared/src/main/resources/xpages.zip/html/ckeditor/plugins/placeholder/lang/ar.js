﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","ar",{title:"خصائص المكان المحتجز",toolbar:"تكوين مكان محتجز",name:"اسم المكان المحتجز",invalidName:"لا يمكن أن يكون المكان المحتجز خاليا ولا يمكن أن يحتوي على أي من الحروف التالية: [، ]، <، >",pathName:"مكان محتجز"});