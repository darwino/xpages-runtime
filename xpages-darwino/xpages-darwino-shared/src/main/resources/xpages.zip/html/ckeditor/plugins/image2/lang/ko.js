﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","ko",{alt:"대체 텍스트",btnUpload:"서버로 보내기",captioned:"캡션된 이미지",captionPlaceholder:"캡션",infoTab:"이미지 정보",lockRatio:"비율 잠금",menu:"이미지 특성",pathName:"이미지",pathNameCaption:"캡션",resetSize:"크기 재설정",resizer:"크기를 조정하려면 클릭하고 끌기",title:"이미지 특성",uploadTab:"업로드",urlMissing:"이미지 소스 URL이 누락되었습니다."});