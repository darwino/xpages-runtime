﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","de",{title:"Platzhalter für Eigenschaften",toolbar:"Platzhalter erstellen",name:"Platzhaltername",invalidName:"Der Platzhalter darf nicht leer sein und keine der folgenden Zeichen enthalten: [, ], <, >",pathName:"Platzhalter "});