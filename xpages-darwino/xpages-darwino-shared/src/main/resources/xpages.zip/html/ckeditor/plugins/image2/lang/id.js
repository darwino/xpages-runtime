﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","id",{alt:"Teks Alternatif",btnUpload:"Kirim ke Server",captioned:"Gambar dengan keterangan",captionPlaceholder:"Keterangan:",infoTab:"Info Gambar",lockRatio:"Rasio Kunci",menu:"Properti Gambar",pathName:"gambar",pathNameCaption:"keterangan",resetSize:"Atur Ulang Ukuran",resizer:"Klik dan seret untuk mengatur ulang ukuran",title:"Properti Gambar",uploadTab:"Unggah",urlMissing:"URL sumber gambar tidak ada."});