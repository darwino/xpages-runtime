﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","pt",{alt:"Texto alternativo",btnUpload:"Enviar para o Servidor",captioned:"Imagem com legenda",captionPlaceholder:"Legenda",infoTab:"Informações sobre a imagem",lockRatio:"Bloquear proporção",menu:"Propriedades da imagem",pathName:"imagem",pathNameCaption:"legenda",resetSize:"Repor tamanho",resizer:"Faça clique e arraste para redimensionar",title:"Propriedades da imagem",uploadTab:"Transferir",urlMissing:"O URL de origem da imagem está em falta."});