﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","pt-br",{title:"Propriedades do Marcador",toolbar:"Criar Marcador",name:"Nome do Marcador'",invalidName:"O marcador não pode estar vazio e não pode conter nenhum dos caracteres a seguir: [, ], <, >",pathName:"marcador"});