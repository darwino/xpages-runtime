﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("devtools","hr",{title:"Informacije o elementu",dialogName:"Naziv prozora dijaloga",tabName:"Naziv kartice",elementId:"ID elementa",elementType:"Tip elementa"});