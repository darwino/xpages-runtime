﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","nl",{loadError:"Fout bij lezen van bestand.",networkError:"Netwerkfout bij uploaden van bestand.",httpError404:"HTTP-fout bij uploaden van bestand (404: Bestand niet gevonden).",httpError403:"HTTP-fout bij uploaden van bestand (403: Verboden).",httpError:"HTTP-fout bij uploaden van bestand (foutstatus: %1).",noUrlError:"Upload-URL is niet gedefinieerd.",responseError:"Onjuiste serverrespons."});