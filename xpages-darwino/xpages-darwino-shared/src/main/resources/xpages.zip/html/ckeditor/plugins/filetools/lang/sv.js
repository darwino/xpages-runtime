﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","sv",{loadError:"Det uppstod ett fel vid läsning av filen.",networkError:"Det uppstod ett nätverksfel vid överföring av filen.",httpError404:"Det uppstod ett HTTP-fel vid överföring av filen (404: Filen hittades inte).",httpError403:"Det uppstod ett HTTP-fel vid överföring av filen (403: Förbjudet).",httpError:"Det uppstod ett HTTP-fel vid överföring av filen (felstatus: %1).",noUrlError:"URL-adressen är inte definierad.",responseError:"Felaktigt serversvar."});