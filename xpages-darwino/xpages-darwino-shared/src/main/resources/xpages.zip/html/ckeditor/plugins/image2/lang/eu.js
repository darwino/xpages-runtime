﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","eu",{alt:"Ordezko testua",btnUpload:"Zerbitzarira bidali",captioned:"Irudi epigrafeduna",captionPlaceholder:"Epigrafea",infoTab:"Irudiaren informazioa",lockRatio:"Blokeatu erlazioa",menu:"Irudiaren propietateak",pathName:"irudia",pathNameCaption:"epigrafea",resetSize:"Tamaina berrezarri",resizer:"Klikatu eta arrastatu tamaina aldatzeko",title:"Irudiaren propietateak",uploadTab:"Gora kargatu",urlMissing:"Irudiaren iturburuaren URLa falta da."});