﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","iw",{title:"תכונות שומר מקום",toolbar:"יצירת שומר מקום",name:"שם שומר מקום",invalidName:"שומר המקום אינו יכול להיות ריק ואינו יכול להכיל אף אחד מהתווים שלהלן: [, ], <, >",pathName:"placeholder"});