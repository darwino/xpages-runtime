﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","ru",{loadError:"Произошла ошибка при чтении файла.",networkError:"Произошла сетевая ошибка при выгрузке файла.",httpError404:"Произошла ошибка HTTP при выгрузке файла (404: File not found).",httpError403:"Произошла ошибка HTTP при выгрузке файла (403: Forbidden).",httpError:"Произошла ошибка HTTP при выгрузке файла (состояние ошибки: %1).",noUrlError:"URL для выгрузки не определен.",responseError:"Неверный ответ сервера."});