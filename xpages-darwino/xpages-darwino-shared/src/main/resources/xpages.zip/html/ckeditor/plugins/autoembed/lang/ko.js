﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("autoembed","ko",{embeddingInProgress:"붙여넣은 URL을 임베드하려고 시도 중...",embeddingFailed:"이 URL은 자동으로 임베드될 수 없습니다."});