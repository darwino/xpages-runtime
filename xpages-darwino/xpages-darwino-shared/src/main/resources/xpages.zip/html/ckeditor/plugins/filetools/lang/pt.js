﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","pt",{loadError:"Ocorreu um erro durante a leitura do ficheiro.",networkError:"Ocorreu um erro de rede durante a transferência do ficheiro.",httpError404:"Ocorreu um erro de HTTP durante a transferência do ficheiro (404: File not found).",httpError403:"Ocorreu um erro de HTTP durante a transferência do ficheiro (403: Forbidden).",httpError:"Ocorreu um erro de HTTP durante a transferência do ficheiro (estado do erro: %1).",noUrlError:"O URL de transferência não está definido.",responseError:"Resposta incorrecta do servidor."});