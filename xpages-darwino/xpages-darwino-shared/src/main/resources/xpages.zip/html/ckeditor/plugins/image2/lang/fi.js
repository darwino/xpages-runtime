﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","fi",{alt:"Vaihtoehtoinen teksti",btnUpload:"Lähetä palvelimeen",captioned:"Kuva ja kuvateksti",captionPlaceholder:"Kuvateksti",infoTab:"Kuvatiedot",lockRatio:"Lukitse suhde",menu:"Kuvan ominaisuudet",pathName:"kuva",pathNameCaption:"kuvateksti",resetSize:"Palauta koko",resizer:"Muuta kokoa napsauttamalla ja vetämällä",title:"Kuvan ominaisuudet",uploadTab:"Siirrä",urlMissing:"Kuvalähteen URL-osoite puuttuu."});