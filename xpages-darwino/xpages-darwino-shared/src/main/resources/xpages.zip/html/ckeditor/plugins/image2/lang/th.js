﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("image2","th",{alt:"ข้อความทางเลือก",btnUpload:"ส่งไปยังเซิร์ฟเวอร์",captioned:"อิมเมจที่มีคำบรรยาย",captionPlaceholder:"คำบรรยาย",infoTab:"ข้อมูลอิมเมจ",lockRatio:"ล็อกอัตราส่วน",menu:"คุณสมบัติรูปภาพ",pathName:"รูปภาพ",pathNameCaption:"คำบรรยาย",resetSize:"รีเซ็ตขนาด",resizer:"คลิกและลากเพื่อปรับขนาด",title:"คุณสมบัติรูปภาพ",uploadTab:"อัพโหลด",urlMissing:"URL ซอร์สรูปภาพสูญหาย"});