﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("autoembed","it",{embeddingInProgress:"Tentativo di integrazione dell'URL incollato...",embeddingFailed:"Questo URL non è stato integrato automaticamente."});