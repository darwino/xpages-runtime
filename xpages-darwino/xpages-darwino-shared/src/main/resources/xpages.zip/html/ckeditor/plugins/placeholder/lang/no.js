﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","no",{title:"Egenskaper for plassholder",toolbar:"Opprett plassholder",name:"Plassholdernavn",invalidName:"Plassholderen kan ikke være tom og kan ikke inneholde noen av følgende tegn: [, ], <, >",pathName:"plassholder"});