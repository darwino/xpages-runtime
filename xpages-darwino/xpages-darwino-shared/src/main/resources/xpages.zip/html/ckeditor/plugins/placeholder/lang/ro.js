﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("placeholder","ro",{title:"Proprietăţi înlocuitor",toolbar:"Creare înlocuitor",name:"Nume înlocuitor",invalidName:"Înlocuitorul nu poate fi gol şi nu poate conţine nici unul dintre caracterele următoare: [, ], <, >",pathName:"înlocuitor"});