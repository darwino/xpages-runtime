﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
 */
CKEDITOR.plugins.setLang("filetools","nb",{loadError:"Det oppstod en feil ved lesing av filen.",networkError:"Det oppstod en nettverksfeil under filopplasting.",httpError404:"HTTP-feil oppstod under filopplasting (404: Filen ble ikke funnet).",httpError403:"HTTP-feil oppstod under filopplasting (403: Forbudt).",httpError:"HTTP-feil oppstod under filopplasting (feilstatus: %1).",noUrlError:"Opplastings-URL ikke definert.",responseError:"Feil serversvar."});