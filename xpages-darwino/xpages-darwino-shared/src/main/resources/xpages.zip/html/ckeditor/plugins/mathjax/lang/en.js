﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/licensePortions Copyright IBM Corp., 2009-2016.
*/
CKEDITOR.plugins.setLang("mathjax","en",{title:"Mathematics in TeX",button:"Math",dialogInput:"Write you TeX here",docUrl:"http://en.wikibooks.org/wiki/LaTeX/Mathematics",docLabel:"TeX documentation",loading:"loading...",pathName:"math"});